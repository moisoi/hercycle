HerCycle handoff bundle.

The original archive could not be recovered byte-for-byte: the supplied raw Git diff
was a plain-text rendering, so the binary payload was replaced with the standard
'Binary files ... differ' marker and the compressed bytes were not carried over.

This archive therefore contains the complete handoff material that the text diff
did carry, namely hercycle-handoff.txt (the full source diff for the restored work).
